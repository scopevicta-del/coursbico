import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { motion, AnimatePresence } from 'framer-motion';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:4000/api';

function apiClient() {
  const token = localStorage.getItem('token');
  return axios.create({
    baseURL: API_URL,
    headers: token ? { Authorization: `Bearer ${token}` } : {},
  });
}

function Header({ onOpenCart, cartCount, onOpenAuth }) {
  return (
    <header className="bg-white shadow-sm fixed top-0 w-full z-50">
      <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
        <div className="text-2xl font-bold">DropCourse<span className="text-indigo-600">.</span></div>
        <div className="flex items-center gap-3">
          <button onClick={onOpenAuth} className="px-4 py-2 bg-indigo-600 text-white rounded">Sign in / Register</button>
        </div>
      </div>
    </header>
  );
}

function Hero({ onSearch }) {
  const [q, setQ] = useState('');
  return (
    <section className="bg-gradient-to-r from-indigo-50 to-white py-32 mt-16">
      <div className="max-w-6xl mx-auto px-4 flex flex-col md:flex-row items-center gap-8">
        <div className="flex-1">
          <h1 className="text-5xl font-extrabold leading-tight">Learn, Build, Succeed</h1>
          <p className="mt-4 text-gray-600">Courses, projects, and mentors at your fingertips.</p>
          <div className="mt-6 flex gap-2">
            <input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search courses..." className="flex-1 border p-3 rounded" />
            <button onClick={()=>onSearch(q)} className="px-5 py-3 bg-indigo-600 text-white rounded">Search</button>
          </div>
        </div>
        <div className="flex-1">
          <motion.img initial={{ opacity:0, y:50 }} animate={{ opacity:1, y:0 }} transition={{ duration:0.8 }} className="rounded shadow-lg" src="https://picsum.photos/seed/hero/900/600" alt="hero" />
        </div>
      </div>
    </section>
  );
}

function CourseCard({ course }) {
  return (
    <motion.div layout className="bg-white rounded-lg shadow-sm overflow-hidden">
      <img src={course.image} className="w-full h-40 object-cover" alt="course" />
      <div className="p-4">
        <h3 className="font-semibold">{course.title}</h3>
        <div className="text-sm text-gray-600">By {course.instructor}</div>
        <div className="mt-3 text-indigo-600 font-bold">{course.price === 0 ? 'Free' : `$${course.price.toFixed(2)}`}</div>
      </div>
    </motion.div>
  );
}

function CoursesGrid({ courses }) {
  return (
    <motion.div layout className="max-w-6xl mx-auto px-4 py-12 grid grid-cols-1 md:grid-cols-3 gap-6">
      {courses.map(c => <CourseCard key={c._id || c.id} course={c} />)}
    </motion.div>
  );
}

function AuthModal({ isOpen, onClose, onAuthSuccess }) {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  async function handleSubmit(e) {
    e.preventDefault();
    try {
      let res;
      if (isLogin) res = await axios.post(\`\${API_URL}/auth/login\`, { email, password });
      else res = await axios.post(\`\${API_URL}/auth/register\`, { name, email, password });
      localStorage.setItem('token', res.data.token);
      onAuthSuccess(res.data.user);
      onClose();
    } catch (err) {
      setError(err.response?.data?.error || 'Error');
    }
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div initial={{ opacity:0 }} animate={{ opacity:1 }} exit={{ opacity:0 }} className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <motion.div initial={{ scale:0.8 }} animate={{ scale:1 }} exit={{ scale:0.8 }} className="bg-white rounded-lg p-6 w-96">
            <h2 className="text-xl font-bold mb-4">{isLogin ? 'Login' : 'Register'}</h2>
            {error && <div className="text-red-500 text-sm mb-2">{error}</div>}
            <form className="flex flex-col gap-2" onSubmit={handleSubmit}>
              {!isLogin && <input value={name} onChange={e=>setName(e.target.value)} placeholder="Name" className="border p-2 rounded" />}
              <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email" type="email" className="border p-2 rounded" />
              <input value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password" type="password" className="border p-2 rounded" />
              <button type="submit" className="mt-2 px-4 py-2 bg-indigo-600 text-white rounded">{isLogin ? 'Login' : 'Register'}</button>
            </form>
            <button onClick={()=>setIsLogin(!isLogin)} className="mt-2 text-sm text-indigo-600">{isLogin ? 'Need an account? Register' : 'Have an account? Login'}</button>
            <button onClick={onClose} className="absolute top-2 right-2 text-gray-500 hover:text-gray-700">✖</button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function AddCourseModal({ isOpen, onClose, onAdd }) {
  const [course, setCourse] = useState({ title:'', instructor:'', price:0, image:'', description:'' });
  const [error, setError] = useState('');

  async function handleSubmit(e) {
    e.preventDefault();
    try {
      const res = await apiClient().post('/courses', course);
      onAdd(res.data);
      onClose();
    } catch (err) {
      setError(err.response?.data?.error || 'Error');
    }
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div initial={{ opacity:0 }} animate={{ opacity:1 }} exit={{ opacity:0 }} className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <motion.div initial={{ scale:0.8 }} animate={{ scale:1 }} exit={{ scale:0.8 }} className="bg-white rounded-lg p-6 w-96 relative">
            <h2 className="text-xl font-bold mb-4">Add Course</h2>
            {error && <div className="text-red-500 text-sm mb-2">{error}</div>}
            <form className="flex flex-col gap-2" onSubmit={handleSubmit}>
              <input placeholder="Title" className="border p-2 rounded" value={course.title} onChange={e=>setCourse({...course,title:e.target.value})} />
              <input placeholder="Instructor" className="border p-2 rounded" value={course.instructor} onChange={e=>setCourse({...course,instructor:e.target.value})} />
              <input type="number" placeholder="Price" className="border p-2 rounded" value={course.price} onChange={e=>setCourse({...course,price:Number(e.target.value)})} />
              <input placeholder="Image URL" className="border p-2 rounded" value={course.image} onChange={e=>setCourse({...course,image:e.target.value})} />
              <textarea placeholder="Description" className="border p-2 rounded" value={course.description} onChange={e=>setCourse({...course,description:e.target.value})} />
              <button type="submit" className="mt-2 px-4 py-2 bg-indigo-600 text-white rounded">Add</button>
            </form>
            <button onClick={onClose} className="absolute top-2 right-2 text-gray-500 hover:text-gray-700">✖</button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export default function App() {
  const [courses, setCourses] = useState([]);
  const [query, setQuery] = useState('');
  const [authOpen, setAuthOpen] = useState(false);
  const [user, setUser] = useState(JSON.parse(localStorage.getItem('user')) || null);
  const [addOpen, setAddOpen] = useState(false);

  async function fetchCourses() {
    try {
      const res = await apiClient().get('/courses');
      setCourses(res.data);
    } catch (err) { console.error(err); }
  }

  useEffect(()=>{ fetchCourses(); }, []);
  const filtered = courses.filter(c => !query || c.title.toLowerCase().includes(query.toLowerCase()));

  function handleAuthSuccess(u) { setUser(u); localStorage.setItem('user', JSON.stringify(u)); }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header onOpenAuth={()=>setAuthOpen(true)} cartCount={0} />
      <Hero onSearch={setQuery} />
      <div className="max-w-6xl mx-auto px-4 py-6 flex justify-between items-center">
        <h2 className="text-xl font-bold">Courses</h2>
        {user && <button onClick={()=>setAddOpen(true)} className="px-4 py-2 bg-indigo-600 text-white rounded">Add Course</button>}
      </div>
      <CoursesGrid courses={filtered} />
      <AuthModal isOpen={authOpen} onClose={()=>setAuthOpen(false)} onAuthSuccess={handleAuthSuccess} />
      <AddCourseModal isOpen={addOpen} onClose={()=>setAddOpen(false)} onAdd={c=>setCourses([c, ...courses])} />
    </div>
  );
}
