# DropCourse Backend (Starter)

This is a minimal Node.js + Express + MongoDB backend starter for the DropCourse clone UI.

Features:
- Mongoose models for User and Course
- Auth routes (register / login) using JWT
- Courses routes (list, get, create) with basic validation

How to run locally:
1. Install MongoDB and run it locally (or use a hosted MongoDB Atlas cluster).
2. Copy `.env.example` to `.env` and update `MONGO_URI` and `JWT_SECRET`.
3. Install dependencies:
   ```bash
   cd server
   npm install
   ```
4. Start server in dev:
   ```bash
   npm run dev
   ```

API endpoints (examples):
- `POST /api/auth/register` { name, email, password }
- `POST /api/auth/login` { email, password }
- `GET /api/courses` - list courses
- `POST /api/courses` - create course (protected)

Security & production notes:
- This is a starter template. Add input validation, rate limiting, production error handling, CORS restrictions, HTTPS, and secure secret management before deploying.
