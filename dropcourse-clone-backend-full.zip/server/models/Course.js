import mongoose from 'mongoose';

const CourseSchema = new mongoose.Schema({
  title: { type: String, required: true },
  instructor: { type: String, required: true },
  price: { type: Number, default: 0 },
  rating: { type: Number, default: 0 },
  students: { type: Number, default: 0 },
  duration: { type: String, default: '0h' },
  tags: { type: [String], default: [] },
  image: { type: String, default: '' },
  description: { type: String, default: '' },
  createdAt: { type: Date, default: Date.now }
});

export default mongoose.model('Course', CourseSchema);
