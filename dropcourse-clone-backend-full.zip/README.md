# DropCourse Fullstack Starter

This bundle contains a frontend (React + Vite + Tailwind) and a backend (Node + Express + MongoDB).

Folders:
- frontend/: React app (run `npm install && npm run dev` inside frontend)
- server/: Express API (run `npm install && npm run dev` inside server)

Quick start (run both):
1. Start MongoDB locally or provide a connection string in `server/.env`.
2. In one terminal run the backend:
   ```bash
   cd server
   npm install
   npm run dev
   ```
3. In another terminal run frontend:
   ```bash
   cd frontend
   npm install
   npm run dev
   ```

The frontend expects the API at `http://localhost:4000/api` — change base URLs in the frontend code if needed.
